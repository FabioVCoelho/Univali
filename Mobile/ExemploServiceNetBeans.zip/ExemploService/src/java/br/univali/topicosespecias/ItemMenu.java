/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.univali.topicosespecias;

import java.util.ArrayList;

/**
 *
 * @author rafael
 */
public class ItemMenu {
    private String nome;
    private String descricao;
    private double preco;
    private double caloria;
    
    
    public static ArrayList<ItemMenu> getInstanciasTeste(){
        ArrayList<ItemMenu>  lista = new ArrayList<ItemMenu>();
        ItemMenu a = new ItemMenu("Banana","-",1.0,125);
        ItemMenu b = new ItemMenu("Maça","-",2.0,11);
        ItemMenu c = new ItemMenu("Mamão","-",1.5,35);
        lista.add(a);
        lista.add(b);
        lista.add(c);
        
        return lista;
    }

    public ItemMenu(String nome, String descricao, double preco, double caloria) {
        this.nome = nome;
        this.descricao = descricao;
        this.preco = preco;
        this.caloria = caloria;
    }    
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public double getCaloria() {
        return caloria;
    }

    public void setCaloria(double caloria) {
        this.caloria = caloria;
    }
    
    
}
