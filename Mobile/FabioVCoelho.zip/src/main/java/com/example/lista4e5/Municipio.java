package com.example.lista4e5;

public class Municipio {
    String nome;
    String codigo;
    String gentilico;
    String prefeito;
    String populacao;
    String area;
    String densidade;
    String escolarizacao;
    String idhm;
    String mortalidade;
    String receita;
    String despesa;
    String pib;

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getGentilico() {
        return gentilico;
    }

    public void setGentilico(String gentilico) {
        this.gentilico = gentilico;
    }

    public String getPrefeito() {
        return prefeito;
    }

    public void setPrefeito(String prefeito) {
        this.prefeito = prefeito;
    }

    public String getEscolarizacao() {
        return escolarizacao;
    }

    public void setEscolarizacao(String escolarizacao) {
        this.escolarizacao = escolarizacao;
    }

    public String getIdhm() {
        return idhm;
    }

    public void setIdhm(String idhm) {
        this.idhm = idhm;
    }

    public String getMortalidade() {
        return mortalidade;
    }

    public void setMortalidade(String mortalidade) {
        this.mortalidade = mortalidade;
    }

    public String getReceita() {
        return receita;
    }

    public void setReceita(String receita) {
        this.receita = receita;
    }

    public String getDespesa() {
        return despesa;
    }

    public void setDespesa(String despesa) {
        this.despesa = despesa;
    }

    public String getPib() {
        return pib;
    }

    public void setPib(String pib) {
        this.pib = pib;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPopulacao() {
        return populacao;
    }

    public void setPopulacao(String populacao) {
        this.populacao = populacao;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getDensidade() {
        return densidade;
    }

    public void setDensidade(String densidade) {
        this.densidade = densidade;
    }
}
