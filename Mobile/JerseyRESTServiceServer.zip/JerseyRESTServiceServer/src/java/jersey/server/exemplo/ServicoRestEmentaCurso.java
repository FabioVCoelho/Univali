/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jersey.server.exemplo;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

@Path("/Ementacurso")
public class ServicoRestEmentaCurso {
    private static ArrayList<EmentaCurso> lista= new ArrayList<EmentaCurso>();
    
    public ServicoRestEmentaCurso(){
        lista.add(new EmentaCurso(1, "Conceitos de HTTP", 8)); 
        lista.add(new EmentaCurso(2, "Introdução a Servlets", 16));
        lista.add(new EmentaCurso(3, "API Jersey Server", 4));
    }
     
       @GET
       @Produces(MediaType.APPLICATION_JSON)
       public String getEmentaCurso(@QueryParam("id") int id) {
          Object resultado=lista;
           if(id>0){
               for(EmentaCurso c:lista){
                   if(c.getId()==id){
                       resultado=c;
                       break;
                   }
               }
           }
           Gson gson = new GsonBuilder().create();
           return gson.toJson(resultado);
       }
       
       @POST
       public Response criaEmenta(@QueryParam("nome") String nome, @QueryParam("cargaHoraria") int cargaHoraria ) {
           EmentaCurso c= new EmentaCurso(lista.size(), nome, cargaHoraria);
           lista.add(c);
           return Response.status(Status.OK).build();
       }
  
       @PUT
       public Response editEmenta(@QueryParam("id") int id,@QueryParam("nome") String nome, @QueryParam("cargaHoraria") int cargaHoraria ) {
             return Response.status(Status.OK).build();
       }
  
       @DELETE
       public Response deleteEmenta(@QueryParam("id") int id) {
           Response resp=null; 
           if(id>0){
               for(EmentaCurso c:lista){
                   if(c.getId()==id){
                       lista.remove(c);
                       resp=Response.status(Status.OK).build();
                       break;
                   }
               }
              resp= Response.status(400).build();
           }
             return resp;
       }
    
}
